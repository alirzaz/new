// {Name: SmallTalk}
// {Description: Gives responses to casual conversation.}

title('Small talk')

intent(
    'hello',
    'hi (there|)',
    'what\'s up',
    reply(
        'Hello I am Ali Raza Training Assistant ',
        'Hi (there|) I am Ali Raza Training Assistant',
        'Hi, what can I do for you? I am Ali Raza Training Assistant',
    ),
);

